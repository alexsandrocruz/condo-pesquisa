# CondominioIntegracao
Software Mobile para gerencimento de um condomínio

Aplicativo que se encontra na etapa final do desenvolvimento para um Condomínio. A priori para acessar o painel de administrador,
existe no canto superior direito um botão com ícone de cadeado, logo após irá pedir um login e senha para acessar o mesmo,
segue as instruções:
Login:admin
Senha:123

O aplicativo foi desenvolvido para funcionar em um tablet, com as dimensões voltadas para telas maiores,
para ser mais exato, foi desenvolvido para o modelo de tablet NEXUS 9 API_28.

By Rocha, Leonardo
Email: leonardorochasjc@gmail.com

