package com.example.condominiointegracao.entidade;

import java.io.Serializable;

public class Usuarios implements Serializable {

    public int idUsuario;
    public String Cadastro;
}
