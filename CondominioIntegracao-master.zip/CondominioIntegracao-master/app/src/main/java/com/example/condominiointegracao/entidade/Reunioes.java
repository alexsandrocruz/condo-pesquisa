package com.example.condominiointegracao.entidade;

import java.io.Serializable;

public class Reunioes implements Serializable {

    public int idReuniao;
    public String Titulo;
    public String Descricao;
    public String Data;
    public String Local;
}
