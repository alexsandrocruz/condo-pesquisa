package com.example.condominiointegracao.entidade;

import java.io.Serializable;

public class Recados implements Serializable {

    public int idRecado;
    public String Titulo;
    public String Descricao;
    public String Data;
}
